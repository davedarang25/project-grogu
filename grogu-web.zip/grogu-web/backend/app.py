"""
app.py
Flask API for the Campus Event Registration and Attendance System.

This is a GUI/API remaster of the original text-based (CLI) project.
The core data-structures-and-algorithms logic is untouched and reused
directly from the original project:
    - core/queue.py     -> Queue  (registration order)
    - core/stack.py      -> Stack  (undo history)
    - core/sorting.py    -> bubble_sort  (report / list sorting)
    - core/timeline.py   -> Timeline  (event slot scheduling + conflict check)
    - core/participant.py-> Participant
    - core/event.py      -> Event
    - core/storage.py    -> CSV persistence
    - core/logger.py     -> system.log event logging

This file only replaces the CLI layer (input()/print() menus) with
JSON HTTP endpoints, so the same logic can later be reused by a
React or Flutter frontend without touching the core modules again.
"""

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "core"))

from flask import Flask, jsonify, request, send_from_directory

from participant import Participant
from event import Event
from queueClass import Queue
from stack import Stack
from sorting import bubble_sort
from timeline import Timeline
from storage import (
    save_student,
    load_students,
    save_all_students,
    save_event,
    load_event,
)
from logger import log_event

FRONTEND_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "frontend")

app = Flask(__name__, static_folder=FRONTEND_DIR, static_url_path="")

# ---------------------------------------------------------------------------
# In-memory state, loaded from the same CSV files the CLI version used.
# ---------------------------------------------------------------------------
participants = []
registration_queue = Queue()
undo_stack = Stack()
timeline = Timeline()


def load_saved_participants():
    participants.clear()
    for studentID, name, section, eventName, eventTime, eventDate, status in load_students():
        participants.append(
            Participant(name, studentID, section, eventName, eventTime, eventDate, status)
        )


load_saved_participants()

saved_event = load_event()
if saved_event:
    _name, _time, _date = saved_event
    current_event = Event(_name, _time, _date)
else:
    current_event = Event()


def serialize_participant(p):
    return {
        "studentID": p.studentID,
        "name": p.name,
        "section": p.section,
        "eventName": p.eventName,
        "eventTime": p.eventTime,
        "eventDate": p.eventDate,
        "status": p.status,
    }


def event_matches_participant(participant, slot):
    return (
        participant.eventName == slot["name"]
        and participant.eventTime == slot["time"]
        and participant.eventDate == slot["date"]
    )


# ---------------------------------------------------------------------------
# Static frontend
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    return send_from_directory(FRONTEND_DIR, "index.html")


# ---------------------------------------------------------------------------
# Events (organizer sets these; students pick from them)
# ---------------------------------------------------------------------------
@app.route("/api/events", methods=["GET"])
def get_events():
    return jsonify(timeline.get_event_slots())


@app.route("/api/events", methods=["POST"])
def create_event():
    data = request.get_json(force=True) or {}
    name = (data.get("name") or "").strip()
    time = (data.get("time") or "").strip()
    date = (data.get("date") or "").strip()

    if not name or not time or not date:
        return jsonify({"success": False, "message": "Event name, time, and date cannot be empty."}), 400

    added, message = timeline.add_event_slot(name, time, date)

    if not added:
        return jsonify({"success": False, "message": message}), 409

    current_event.setDetails(name, time, date)
    save_event(name, time, date)
    log_event(f"Event details set: Name={name}, Time={time}, Date={date}")

    return jsonify({"success": True, "message": message, "event": {"name": name, "time": time, "date": date}})


@app.route("/api/events/summary", methods=["GET"])
def event_attendance_summary():
    """Attendance breakdown for one event slot (used before deleting it)."""
    name = request.args.get("name", "")
    time = request.args.get("time", "")
    date = request.args.get("date", "")
    slot = {"name": name, "time": time, "date": date}

    attendees = [serialize_participant(p) for p in participants if event_matches_participant(p, slot)]
    present = sum(1 for a in attendees if a["status"].lower() == "present")
    absent = len(attendees) - present

    return jsonify({
        "event": slot,
        "attendees": attendees,
        "totalAttendees": len(attendees),
        "present": present,
        "absent": absent,
    })


@app.route("/api/events", methods=["DELETE"])
def delete_event():
    data = request.get_json(force=True) or {}
    slot = {
        "name": (data.get("name") or "").strip(),
        "time": (data.get("time") or "").strip(),
        "date": (data.get("date") or "").strip(),
    }

    deleted = timeline.delete_event_slot(slot)

    if not deleted:
        return jsonify({"success": False, "message": "Event was not found."}), 404

    global current_event
    if (
        current_event.name == slot["name"]
        and current_event.time == slot["time"]
        and current_event.date == slot["date"]
    ):
        remaining = timeline.get_event_slots()
        if remaining:
            latest = remaining[-1]
            current_event.setDetails(latest["name"], latest["time"], latest["date"])
            save_event(latest["name"], latest["time"], latest["date"])
        else:
            current_event.setDetails("Not set", "Not set", "Not set")
            save_event("Not set", "Not set", "Not set")

    log_event(f"Deleted finished event: {slot['name']} | {slot['date']} | {slot['time']}")
    return jsonify({"success": True, "message": "Finished event deleted successfully."})


@app.route("/api/event/current", methods=["GET"])
def get_current_event():
    return jsonify({
        "name": current_event.name,
        "time": current_event.time,
        "date": current_event.date,
        "attendeeCount": len(participants),
    })


# ---------------------------------------------------------------------------
# Participants: register / attendance / search / list
# ---------------------------------------------------------------------------
@app.route("/api/participants", methods=["GET"])
def list_participants():
    sort_by = request.args.get("sort", "")
    status_filter = request.args.get("status", "")

    working_list = participants

    if status_filter:
        working_list = [p for p in working_list if p.status.lower() == status_filter.lower()]

    if sort_by == "name_asc":
        working_list = bubble_sort(working_list, lambda p: p.name.lower(), ascending=True)
    elif sort_by == "name_desc":
        working_list = bubble_sort(working_list, lambda p: p.name.lower(), ascending=False)
    elif sort_by == "section":
        working_list = bubble_sort(working_list, lambda p: p.section.lower(), ascending=True)

    return jsonify([serialize_participant(p) for p in working_list])


@app.route("/api/participants/register", methods=["POST"])
def register_participant():
    data = request.get_json(force=True) or {}
    name = (data.get("name") or "").strip()
    studentID = (data.get("studentID") or "").strip()
    section = (data.get("section") or "").strip()
    event_index = data.get("eventIndex")

    if not name or not studentID or not section:
        return jsonify({"success": False, "message": "Student name, student ID, and section cannot be empty."}), 400

    for p in participants:
        if p.studentID == studentID:
            return jsonify({"success": False, "message": "Duplicate ID found. Registration failed."}), 409

    event_slots = timeline.get_event_slots()
    if event_index is None or not isinstance(event_index, int) or event_index < 0 or event_index >= len(event_slots):
        return jsonify({"success": False, "message": "Invalid event selection."}), 400

    selected_event = event_slots[event_index]

    new_participant = Participant(
        name, studentID, section,
        selected_event["name"], selected_event["time"], selected_event["date"],
    )

    participants.append(new_participant)
    registration_queue.enqueue(new_participant)
    undo_stack.push(("register", new_participant))

    save_student(
        studentID, name, section,
        selected_event["name"], selected_event["time"], selected_event["date"],
        new_participant.status,
    )

    log_event(f"Registered student: {new_participant.viewDetails()}")

    return jsonify({"success": True, "message": "Registration successful.", "participant": serialize_participant(new_participant)})


@app.route("/api/participants/attendance", methods=["POST"])
def mark_attendance():
    data = request.get_json(force=True) or {}
    studentID = (data.get("studentID") or "").strip()

    for p in participants:
        if p.studentID == studentID:
            if p.status == "Present":
                return jsonify({"success": False, "message": f"{p.name} is already marked as Present."}), 409

            previous_status = p.status
            p.status = "Present"

            undo_stack.push(("attendance", p, previous_status))
            save_all_students(participants)

            log_event(f"Attendance marked: {p.viewDetails()}")
            return jsonify({"success": True, "message": f"{p.name} has been marked as Present.", "participant": serialize_participant(p)})

    return jsonify({"success": False, "message": "Student not found."}), 404


@app.route("/api/participants/search", methods=["GET"])
def search_participant():
    studentID = request.args.get("studentID", "").strip()

    for p in participants:
        if p.studentID == studentID:
            return jsonify({"found": True, "participant": serialize_participant(p)})

    return jsonify({"found": False, "message": "Participant not found."}), 404


# ---------------------------------------------------------------------------
# Undo
# ---------------------------------------------------------------------------
@app.route("/api/undo", methods=["POST"])
def undo_action():
    if undo_stack.isEmpty():
        return jsonify({"success": False, "message": "No actions to undo."}), 409

    action_data = undo_stack.pop()
    action = action_data[0]

    if action == "register":
        participant = action_data[1]
        if participant in participants:
            participants.remove(participant)
            save_all_students(participants)
            log_event(f"Undo registration: {participant.viewDetails()}")
            return jsonify({"success": True, "message": f"Undo: Removed {participant.name} from registration."})
        return jsonify({"success": False, "message": "Unable to undo registration. Student was not found."}), 404

    if action == "attendance":
        participant = action_data[1]
        previous_status = action_data[2]
        participant.status = previous_status
        save_all_students(participants)
        log_event(f"Undo attendance: {participant.viewDetails()}")
        return jsonify({"success": True, "message": f"Undo: Restored {participant.name}'s attendance to {previous_status}."})

    return jsonify({"success": False, "message": "Unknown action. Nothing was undone."}), 400


# ---------------------------------------------------------------------------
# Reports
# ---------------------------------------------------------------------------
SORT_KEYS = {
    "name": lambda p: p.name.lower(),
    "id": lambda p: p.studentID.lower(),
    "section": lambda p: p.section.lower(),
    "status": lambda p: p.status.lower(),
    "event": lambda p: p.eventName.lower(),
}


@app.route("/api/report", methods=["GET"])
def generate_report():
    report_type = request.args.get("type", "overall")
    sort_key = request.args.get("sort", "name")
    section = request.args.get("section", "")
    event_index = request.args.get("eventIndex", type=int)

    if report_type == "section":
        if not section:
            return jsonify({"success": False, "message": "Section cannot be empty."}), 400
        report_list = [p for p in participants if p.section.lower() == section.lower()]
        title = f"Attendance Report for Section {section}"

    elif report_type == "event":
        event_slots = timeline.get_event_slots()
        if event_index is None or event_index < 0 or event_index >= len(event_slots):
            return jsonify({"success": False, "message": "Invalid event selection."}), 400
        slot = event_slots[event_index]
        report_list = [p for p in participants if event_matches_participant(p, slot)]
        title = f"Attendance Report for {slot['name']} ({slot['date']} | {slot['time']})"

    else:
        report_list = participants
        title = "Overall Attendance Report"

    key_fn = SORT_KEYS.get(sort_key, SORT_KEYS["name"])
    sorted_list = bubble_sort(report_list, key_fn, ascending=True)

    return jsonify({"title": title, "participants": [serialize_participant(p) for p in sorted_list]})


if __name__ == "__main__":
    app.run(debug=True, port=5000, use_reloader=False)
