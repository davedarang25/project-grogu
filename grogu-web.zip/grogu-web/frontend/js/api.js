// api.js — thin wrapper around the Flask backend endpoints.

const API_BASE = "/api";

async function apiRequest(path, options = {}) {
  const res = await fetch(API_BASE + path, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });

  let body = null;
  try {
    body = await res.json();
  } catch (e) {
    body = null;
  }

  if (!res.ok) {
    const message = (body && body.message) || `Request failed (${res.status})`;
    const error = new Error(message);
    error.body = body;
    throw error;
  }

  return body;
}

const api = {
  getEvents: () => apiRequest("/events"),
  createEvent: (payload) =>
    apiRequest("/events", { method: "POST", body: JSON.stringify(payload) }),
  deleteEvent: (payload) =>
    apiRequest("/events", { method: "DELETE", body: JSON.stringify(payload) }),
  getEventSummary: (slot) =>
    apiRequest(
      `/events/summary?name=${encodeURIComponent(slot.name)}&time=${encodeURIComponent(slot.time)}&date=${encodeURIComponent(slot.date)}`
    ),
  getCurrentEvent: () => apiRequest("/event/current"),

  getParticipants: (params = {}) => {
    const query = new URLSearchParams(params).toString();
    return apiRequest(`/participants${query ? "?" + query : ""}`);
  },
  registerParticipant: (payload) =>
    apiRequest("/participants/register", { method: "POST", body: JSON.stringify(payload) }),
  markAttendance: (studentID) =>
    apiRequest("/participants/attendance", { method: "POST", body: JSON.stringify({ studentID }) }),
  searchParticipant: (studentID) =>
    apiRequest(`/participants/search?studentID=${encodeURIComponent(studentID)}`),

  undo: () => apiRequest("/undo", { method: "POST" }),

  getReport: (params = {}) => {
    const query = new URLSearchParams(params).toString();
    return apiRequest(`/report${query ? "?" + query : ""}`);
  },
};
