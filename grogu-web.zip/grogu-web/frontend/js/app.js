// app.js — screen navigation + form wiring for the Campus Event system.

const views = {
  role: document.getElementById("view-role"),
  student: document.getElementById("view-student"),
  organizer: document.getElementById("view-organizer"),
};
const breadcrumb = document.getElementById("breadcrumb");
const homeBtn = document.getElementById("homeBtn");
const toast = document.getElementById("toast");

let toastTimer = null;
function showToast(message, isError = false) {
  toast.textContent = message;
  toast.classList.remove("hidden");
  toast.classList.toggle("error", isError);
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.add("hidden"), 3200);
}

function showView(name) {
  Object.entries(views).forEach(([key, el]) => el.classList.toggle("active", key === name));
  homeBtn.classList.toggle("hidden", name === "role");
  breadcrumb.textContent =
    name === "role" ? "Select user type" : name === "student" ? "Student menu" : "Organizer menu";
}

homeBtn.addEventListener("click", () => showView("role"));

document.querySelectorAll(".role-card").forEach((card) => {
  card.addEventListener("click", () => {
    const role = card.dataset.role;
    showView(role);
    if (role === "student") initStudentView();
    if (role === "organizer") initOrganizerView();
  });
});

// ---------- Tab switching (shared by both menus) ----------
document.querySelectorAll(".view").forEach((view) => {
  view.querySelectorAll(".tab-btn[data-tab]").forEach((btn) => {
    btn.addEventListener("click", () => {
      view.querySelectorAll(".tab-btn[data-tab]").forEach((b) => b.classList.remove("active"));
      view.querySelectorAll(".tab-panel").forEach((p) => p.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById(btn.dataset.tab).classList.add("active");
    });
  });
});

function escapeHtml(text) {
  const div = document.createElement("div");
  div.textContent = text ?? "";
  return div.innerHTML;
}

function statusPill(status) {
  const cls = status.toLowerCase() === "present" ? "present" : "absent";
  return `<span class="status-pill ${cls}">${escapeHtml(status)}</span>`;
}

function renderParticipantTable(container, participants, { showEvent = true } = {}) {
  if (!participants.length) {
    container.innerHTML = "";
    return;
  }
  const rows = participants
    .map(
      (p) => `
      <tr>
        <td>${escapeHtml(p.studentID)}</td>
        <td>${escapeHtml(p.name)}</td>
        <td>${escapeHtml(p.section)}</td>
        ${showEvent ? `<td>${escapeHtml(p.eventName)}</td>` : ""}
        <td>${statusPill(p.status)}</td>
      </tr>`
    )
    .join("");

  container.innerHTML = `
    <table class="ledger">
      <thead>
        <tr>
          <th>ID</th><th>Name</th><th>Section</th>${showEvent ? "<th>Event</th>" : ""}<th>Status</th>
        </tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>`;
}

function formatSlotLabel(slot) {
  return `${slot.name} — ${slot.date}, ${slot.time}`;
}

async function populateEventSelect(selectEl) {
  selectEl.innerHTML = "";
  const events = await api.getEvents();
  if (!events.length) {
    selectEl.innerHTML = `<option value="">No events available</option>`;
    return events;
  }
  events.forEach((slot, index) => {
    const opt = document.createElement("option");
    opt.value = index;
    opt.textContent = formatSlotLabel(slot);
    selectEl.appendChild(opt);
  });
  return events;
}

/* =========================================================
   STUDENT VIEW
   ========================================================= */
let studentInitialized = false;

function initStudentView() {
  populateEventSelect(document.getElementById("reg-event"));
  if (studentInitialized) return;
  studentInitialized = true;

  // --- Register ---
  document.getElementById("registerForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const eventSelect = document.getElementById("reg-event");
    if (!eventSelect.value && eventSelect.value !== "0") {
      showToast("No events are currently available for registration.", true);
      return;
    }
    try {
      const result = await api.registerParticipant({
        name: document.getElementById("reg-name").value.trim(),
        studentID: document.getElementById("reg-id").value.trim(),
        section: document.getElementById("reg-section").value.trim(),
        eventIndex: Number(eventSelect.value),
      });
      showToast(result.message);
      e.target.reset();
      populateEventSelect(eventSelect);
    } catch (err) {
      showToast(err.message, true);
    }
  });

  // --- Attendance ---
  document.getElementById("attendanceForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const studentID = document.getElementById("att-id").value.trim();
    try {
      const result = await api.markAttendance(studentID);
      showToast(result.message);
      e.target.reset();
    } catch (err) {
      showToast(err.message, true);
    }
  });

  // --- Search ---
  document.getElementById("searchForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const studentID = document.getElementById("search-id").value.trim();
    const box = document.getElementById("searchResult");
    try {
      const result = await api.searchParticipant(studentID);
      renderParticipantTable(box, [result.participant]);
    } catch (err) {
      box.innerHTML = "";
      showToast(err.message, true);
    }
  });

  // --- Report ---
  const reportType = document.getElementById("report-type");
  const sectionWrap = document.getElementById("report-section-wrap");
  const eventWrap = document.getElementById("report-event-wrap");

  reportType.addEventListener("change", () => {
    sectionWrap.classList.toggle("hidden", reportType.value !== "section");
    eventWrap.classList.toggle("hidden", reportType.value !== "event");
    if (reportType.value === "event") populateEventSelect(document.getElementById("report-event"));
  });

  document.getElementById("reportForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const params = {
      type: reportType.value,
      sort: document.getElementById("report-sort").value,
    };
    if (reportType.value === "section") {
      params.section = document.getElementById("report-section").value.trim();
    }
    if (reportType.value === "event") {
      const idx = document.getElementById("report-event").value;
      if (idx === "") return showToast("No events available.", true);
      params.eventIndex = idx;
    }

    const titleEl = document.getElementById("report-title");
    const wrap = document.getElementById("report-table-wrap");

    try {
      const result = await api.getReport(params);
      titleEl.textContent = result.title;
      titleEl.classList.remove("hidden");
      if (!result.participants.length) {
        wrap.innerHTML = `<div class="result-box">No participants found.</div>`;
      } else {
        wrap.innerHTML = "";
        renderParticipantTable(wrap, result.participants);
        wrap.firstElementChild.classList.add("ledger");
      }
    } catch (err) {
      showToast(err.message, true);
    }
  });

  // --- Undo (shared button, top right of student tab bar) ---
  document.getElementById("s-undo").addEventListener("click", async () => {
    try {
      const result = await api.undo();
      showToast(result.message);
    } catch (err) {
      showToast(err.message, true);
    }
  });
}

/* =========================================================
   ORGANIZER VIEW
   ========================================================= */
let organizerInitialized = false;

async function refreshEventSlotList() {
  const box = document.getElementById("event-slot-list");
  const events = await api.getEvents();
  if (!events.length) {
    box.innerHTML = "";
    return;
  }
  box.innerHTML = events
    .map(
      (slot) => `
      <div class="event-slot-card">
        <div>
          <div class="slot-name">${escapeHtml(slot.name)}</div>
          <div class="slot-meta">${escapeHtml(slot.date)} · ${escapeHtml(slot.time)}</div>
        </div>
      </div>`
    )
    .join("");
}

function initOrganizerView() {
  refreshEventSlotList();
  refreshEventSummary();

  if (organizerInitialized) return;
  organizerInitialized = true;

  // --- Set Event ---
  document.getElementById("eventForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const dateInput = document.getElementById("ev-date").value; // yyyy-mm-dd
    const displayDate = dateInput
      ? new Date(dateInput + "T00:00:00").toLocaleDateString(undefined, {
          year: "numeric",
          month: "long",
          day: "numeric",
        })
      : "";
    try {
      const result = await api.createEvent({
        name: document.getElementById("ev-name").value.trim(),
        time: document.getElementById("ev-time").value.trim(),
        date: displayDate,
      });
      showToast(result.message);
      e.target.reset();
      refreshEventSlotList();
      refreshEventSummary();
    } catch (err) {
      showToast(err.message, true);
    }
  });

  // --- Attendee List ---
  document.getElementById("loadAttendeesBtn").addEventListener("click", async () => {
    const filter = document.getElementById("attendee-filter").value;
    const params = {};
    if (filter === "name_asc" || filter === "name_desc" || filter === "section") params.sort = filter;
    if (filter === "present") params.status = "present";
    if (filter === "absent") params.status = "absent";

    const wrap = document.getElementById("attendee-table-wrap");
    try {
      const participants = await api.getParticipants(params);
      if (!participants.length) {
        wrap.innerHTML = `<div class="result-box">No attendees found for this option.</div>`;
      } else {
        wrap.innerHTML = "";
        renderParticipantTable(wrap, participants);
        wrap.firstElementChild.classList.add("ledger");
      }
    } catch (err) {
      showToast(err.message, true);
    }
  });

  // --- Delete Finished Event ---
  populateEventSelect(document.getElementById("delete-event-select"));

  document.getElementById("previewDeleteBtn").addEventListener("click", async () => {
    const select = document.getElementById("delete-event-select");
    const events = await populateEventSelect(select);
    if (!events.length || select.value === "") return showToast("No event slots available.", true);

    const slot = events[Number(select.value)];
    const summary = await api.getEventSummary(slot);
    const box = document.getElementById("delete-preview");

    box.innerHTML = `
      <p><strong>${escapeHtml(slot.name)}</strong> — ${escapeHtml(slot.date)}, ${escapeHtml(slot.time)}</p>
      <p>Total Attendees: ${summary.totalAttendees} &nbsp;|&nbsp; Present: ${summary.present} &nbsp;|&nbsp; Absent: ${summary.absent}</p>
    `;
    if (summary.attendees.length) {
      const tableWrap = document.createElement("div");
      renderParticipantTable(tableWrap, summary.attendees, { showEvent: false });
      box.appendChild(tableWrap);
    }

    document.getElementById("confirmDeleteBtn").classList.remove("hidden");
    document.getElementById("confirmDeleteBtn").dataset.slot = JSON.stringify(slot);
  });

  document.getElementById("confirmDeleteBtn").addEventListener("click", async () => {
    const btn = document.getElementById("confirmDeleteBtn");
    const slot = JSON.parse(btn.dataset.slot || "{}");
    if (!slot.name) return;
    if (!confirm(`Delete "${slot.name}" (${slot.date}, ${slot.time})? This cannot be undone.`)) return;

    try {
      const result = await api.deleteEvent(slot);
      showToast(result.message);
      btn.classList.add("hidden");
      document.getElementById("delete-preview").innerHTML = "";
      populateEventSelect(document.getElementById("delete-event-select"));
      refreshEventSlotList();
      refreshEventSummary();
    } catch (err) {
      showToast(err.message, true);
    }
  });
}

async function refreshEventSummary() {
  const box = document.getElementById("event-summary-box");
  const current = await api.getCurrentEvent();
  box.innerHTML = `
    <p><strong>Event Name:</strong> ${escapeHtml(current.name)}</p>
    <p><strong>Event Time:</strong> ${escapeHtml(current.time)}</p>
    <p><strong>Event Date:</strong> ${escapeHtml(current.date)}</p>
    <p><strong>Attendees:</strong> ${current.attendeeCount} registered</p>
  `;
}

showView("role");
