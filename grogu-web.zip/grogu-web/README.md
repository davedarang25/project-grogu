# Campus Event Registration & Attendance — GUI Remaster

This is a browser-based (HTML/CSS/JS) remaster of the original text-based
Data Structures & Algorithms project (`project-grogu`). It keeps every piece
of the original logic — the `Queue`, `Stack`, `Timeline` (with conflict
checking), bubble sort, and CSV persistence — and only replaces the CLI
`input()`/`print()` menus with a Flask JSON API and a web UI.

This structure (a plain REST API backend) is intentional: it's set up so you
can later swap the `frontend/` folder for a React app, or point a Flutter app
at the same `backend/`, without touching any of the core logic again.

## Project structure

```
grogu-web/
├── backend/
│   ├── app.py              # Flask app: HTTP routes only, no business logic
│   ├── requirements.txt
│   ├── core/                # Reused almost unchanged from the original project
│   │   ├── participant.py
│   │   ├── event.py
│   │   ├── queueClass.py    # (renamed from queue.py — avoids clashing with Python's stdlib queue)
│   │   ├── stack.py
│   │   ├── sorting.py       # bubble_sort
│   │   ├── timeline.py      # event slot scheduling + overlap detection
│   │   ├── storage.py       # CSV persistence
│   │   └── logger.py
│   └── data/                 # students.txt, event_slots.txt, event.txt, system.log
│                              # (created automatically on first run)
└── frontend/
    ├── index.html
    ├── css/style.css
    └── js/
        ├── api.js            # fetch() wrapper around the backend endpoints
        └── app.js             # screen navigation + form wiring
```

## How to run it

1. Install Flask (only dependency):
   ```
   pip install -r backend/requirements.txt
   ```
2. Start the server from the `backend/` folder:
   ```
   cd backend
   python app.py
   ```
3. Open your browser to **http://127.0.0.1:5000** — the Flask app serves the
   frontend directly, so there's nothing else to run.

Data is stored as CSV files in `backend/data/` — same format as the original
`students.txt` / `event_slots.txt` / `event.txt`.

## What changed vs. the original CLI

| Original (CLI)                         | Remaster (Web)                                   |
|-----------------------------------------|---------------------------------------------------|
| `menu.py` role/menu prompts             | Role-select screen + tabbed menus (`index.html`)  |
| `registration.py`, `attendance.py`, `search.py`, `undo.py`, `report.py`, `organizer.py` | Rewritten as Flask routes in `app.py` that return JSON instead of printing |
| `input()` for every field                | HTML forms                                        |
| Console `print()` tables                 | Ledger-style HTML tables                          |
| In-memory `participants` list + CSV files | Same — still in-memory Python list on server, still CSV files |

The **data structures themselves were not touched**: `Queue`, `Stack`,
`Timeline`, and `bubble_sort` in `core/` are the same files (`queue.py` was
only renamed to `queueClass.py` to avoid shadowing Python's built-in `queue`
module when imported inside Flask).

## Feature parity checklist

- [x] Organizer: set event details (with overlap/conflict validation)
- [x] Organizer: view attendee list (sort by name asc/desc, section, filter by status)
- [x] Organizer: view current event summary
- [x] Organizer: preview + delete a finished event slot
- [x] Student: register for an event (duplicate ID rejected)
- [x] Student: mark attendance by ID
- [x] Student: search participant by ID
- [x] Student: generate report (overall / by section / by event, 5 sort keys)
- [x] Undo last register/attendance action (stack-based)

## Next steps (React / Flutter)

The `backend/` folder is a standalone REST API — nothing in it knows about
HTML. To move to React:
- Keep `backend/` as-is (maybe add `flask-cors` if the React dev server runs
  on a different port).
- Rebuild `frontend/` as a React app that calls the same `/api/...` endpoints
  in `app.py`.

For Flutter, the same `backend/` can be called with `package:http` — the API
already returns plain JSON with no HTML mixed in.
